<?php
/**
 * Permissions Ukrainian Lexicon Entries for miniShop2
 *
 * @package minishop2
 * @subpackage lexicon
 */
$_lang['mscategory_save'] = 'Дозволяє створення\зміну категорії магазина';
$_lang['msproduct_save'] = 'Дозволяє створення\зміну товару магазина';

$_lang['msorder_view'] = 'Дозволяє перегляд замовлення';
$_lang['msorder_list'] = 'Дозволяє показ списку замовлень';
$_lang['msorder_save'] = 'Дозволяє зміну замовлення';

$_lang['mssetting_view'] = 'Дозволяє перегляд налаштувань';
$_lang['mssetting_list'] = 'Дозволяє показ списку налаштувань';
$_lang['mssetting_save'] = 'Дозволяє створення\зміну налаштувань';

$_lang['msproductfile_save'] = 'Дозволяє створення\зміну файлів товару';
$_lang['msproductfile_generate'] = 'Дозволяє геренрацію мініатюр зображень товару';
$_lang['msproductfile_list'] = 'Дозволяє показ списку файлів товару';

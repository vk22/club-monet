<?php
class myCartHandler extends msCartHandler{


    private $discountPercent5 = 5.0;
    private $discountPercent10 = 10.0;
    private $discountPercent15 = 15.0;
    private $discountPercent20 = 20.0;

    public function getDiscountPercent(){
        return $this->discountPercent;
    }

    /* @inheritdoc} */
    public function status($data = array()) {
        $status = parent::status($data);

        // margin && discount
        $status['discount'] = $this->getCartDiscount();
        $status['old_cost'] = $this->saveOldCostEx($status['total_cost']);
        $status['total_cost'] = $this->calcTotalCostEx($status['total_cost'], $status['discount']);


        return $status;
    }

    public function calcTotalCostEx($total_cost, $discount){
        $result = $total_cost;

        if(!empty($discount)){
            //$result = $this->roundCost($total_cost - $discount);
            $result = $total_cost - $discount;
        }
        return $result;
    }

    public function saveOldCostEx($total_cost){
        $result = $total_cost;
        return $result;
    }    


    public function getCartDiscount(){
        $countSet = 0;
        $totalCost = 0;
        foreach ($this->cart as $item) {
            if (empty($item['ctx']) || $item['ctx'] == $this->modx->context->key){
                if($item['count'] >= 4){
                    $countSet ++;
                }
                $totalCost += $item['price'] * $item['count'];
                //$modx->log(modX::LOG_LEVEL_INFO, print_r($totalCost, true)); 
            }
        }


         //скидка, если в корзине сумма больше чем
        
        if($totalCost < 10000){
              return 0;
              } else if ($totalCost >= 10000 && $totalCost < 20000){
                  return $this->roundCost($totalCost * ($this->discountPercent5 / 100.0));
              } else if ($totalCost >= 20000 && $totalCost < 50000){
                 return $this->roundCost($totalCost * ($this->discountPercent10 / 100.0));
              } else if ($totalCost >= 50000 && $totalCost < 100000){
                  return $this->roundCost($totalCost * ($this->discountPercent15 / 100.0));
              } else if ($totalCost >= 100000){
                  return $this->roundCost($totalCost * ($this->discountPercent20 / 100.0));
              }        
        
    }

    public function roundCost($cost){
        // return round($cost / 50) * 50;
        return $cost;
    }
}
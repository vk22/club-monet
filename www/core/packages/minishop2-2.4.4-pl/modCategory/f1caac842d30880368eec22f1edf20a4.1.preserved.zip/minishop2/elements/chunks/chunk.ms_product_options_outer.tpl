<table>
    [[+rows]]
</table>
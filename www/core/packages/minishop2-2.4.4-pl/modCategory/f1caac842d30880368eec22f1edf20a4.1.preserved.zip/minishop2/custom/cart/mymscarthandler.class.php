<?php
class myCartHandler extends msCartHandler{


    private $discountPercent5 = 3.0;
    private $discountPercent10 = 5.0;
    private $discountPercent20 = 10.0;
    private $discountPercent50 = 15.0;
    private $discountPercent100 = 20.0;

    public function getDiscountPercent(){
        return $this->discountPercent;
    }

    /* @inheritdoc} */
    public function status($data = array()) {
        $status = parent::status($data);

        // margin && discount
        $status['discount'] = $this->getCartDiscount();
        $status['old_cost'] = $this->saveOldCostEx($status['total_cost']);
        $status['total_cost'] = $this->calcTotalCostEx($status['total_cost'], $status['discount']);


        return $status;
    }

    public function calcTotalCostEx($total_cost, $discount){
        $result = $total_cost;

        if(!empty($discount)){
            //$result = $this->roundCost($total_cost - $discount);
            $result = $total_cost - $discount;
        }
        return $result;
    }

    public function saveOldCostEx($total_cost){
        $result = $total_cost;
        return $result;
    }    


    public function getCartDiscount(){
        $countSet = 0;
        $totalCost = 0;
        foreach ($this->cart as $item) {
            if (empty($item['ctx']) || $item['ctx'] == $this->modx->context->key){
                if($item['count'] >= 4){
                    $countSet ++;
                }
                $totalCost += $item['price'] * $item['count'];
            }
        }

        // скидка, если в корзине сумма больше чем
        if($totalCost < 7500){
            return 0;
        }
        if($totalCost >= 7500){
            return $this->roundCost($totalCost * ($this->discountPercent5 / 100.0));
        }
        if($totalCost >= 15000){
            return $this->roundCost($totalCost * ($this->discountPercent10 / 100.0));
        }
        if($totalCost >= 30000){
            return $this->roundCost($totalCost * ($this->discountPercent20 / 100.0));
        }
        if($totalCost >= 60000){
            return $this->roundCost($totalCost * ($this->discountPercent50 / 100.0));
        }
        if($totalCost >= 120000){
            return $this->roundCost($totalCost * ($this->discountPercent100 / 100.0));
        }        
        
    }

    public function roundCost($cost){
        // return round($cost / 50) * 50;
        return $cost;
    }
}
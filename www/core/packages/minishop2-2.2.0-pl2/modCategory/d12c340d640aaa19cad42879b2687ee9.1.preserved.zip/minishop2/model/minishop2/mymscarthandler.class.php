<?php
class myCartHandler extends msCartHandler{

    private $marginPercent = 5.0;
    private $discountPercent = 2.0;

    public function getMarginPercent(){
        return $this->marginPercent;
    }
    public function getDiscountPercent(){
        return $this->discountPercent;
    }

    /* @inheritdoc} */
    public function status($data = array()) {
        $status = parent::status($data);

        // margin && discount
        $status['margin'] = $this->getCartMargin();
        $status['discount'] = $this->getCartDiscount();
        //$status['total_cost_ex'] = $this->calcTotalCostEx($status['total_cost'], $status['margin'], $status['discount']);
        $status['total_cost'] = $this->calcTotalCostEx($status['total_cost'], $status['margin'], $status['discount']);

        return $status;
    }

    public function calcTotalCostEx($total_cost, $margin, $discount){
        $result = $total_cost;
        if(!empty($margin)){
            //$result = $this->roundCost($total_cost + $margin);
            $result = $total_cost + $margin;
        }
        if(!empty($discount)){
            //$result = $this->roundCost($total_cost - $discount);
            $result = $total_cost - $discount;
        }
        return $result;
    }

    public function getCartMargin(){
        $count = 0;
        $totalCount = 0;
        $totalCost = 0;
        $tmpPrice = 0;
        foreach ($this->cart as $item) {
            if (empty($item['ctx']) || $item['ctx'] == $this->modx->context->key){
                $count++;
                $totalCount += $item['count'];
                $tmpPrice = $item['price'];
                $totalCost += $item['price'] * $item['count'];
            }
        }

        // наценка, если в корзине 1 товарная позиция, с кол-вом 2 шт и ценой менее 4000 рублей
        if($count == 1 && $totalCount <= 2 && $tmpPrice < 4000){
            return $this->roundCost($totalCost * ($this->marginPercent / 100.0));
        }
        return 0;
    }

    public function getCartDiscount(){
        $countSet = 0;
        $totalCost = 0;
        foreach ($this->cart as $item) {
            if (empty($item['ctx']) || $item['ctx'] == $this->modx->context->key){
                if($item['count'] >= 4){
                    $countSet ++;
                }
                $totalCost += $item['price'] * $item['count'];
            }
        }

        // скидка, если в корзине 2 комплекта
        if($countSet >= 2){
            return $this->roundCost($totalCost * ($this->discountPercent / 100.0));
        }
        return 0;
    }

    public function roundCost($cost){
        return round($cost / 50) * 50;
    }
}
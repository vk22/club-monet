<?php
return array(
	'fields' => array(
		'nominal' => 0
		,'year' => 0
		,'metal' => NULL
		,'theme' => NULL

	)
	,'fieldMeta' => array(
		'nominal' => array(
			'dbtype' => 'decimal',
			'precision' => '12,2',
			'phptype' => 'float',
			'null' => false,
			'default' => 0
		),
		'year' => array(
			'dbtype' => 'decimal',
			'precision' => '12,2',
			'phptype' => 'float',
			'null' => false,
			'default' => 0
		),
		'metal' => array(
			'dbtype' => 'varchar'
			,'precision' => '5'
			,'phptype' => 'string'
			,'null' => true
			,'default' => NULL
		),
		'theme' => array(
			'dbtype' => 'varchar'
			,'precision' => '5'
			,'phptype' => 'string'
			,'null' => true
			,'default' => NULL
		)							

	)
	,'indexes' => array(
		'nominal' => array (
			'alias' => 'nominal'
			,'primary' => false
			,'unique' => false
			,'type' => 'BTREE'
			,'columns' => array (
				'action' => array (
					'length' => ''
					,'collation' => 'A'
					,'null' => false
				)
			)
		),
		'year' => array (
			'alias' => 'year'
			,'primary' => false
			,'unique' => false
			,'type' => 'BTREE'
			,'columns' => array (
				'action' => array (
					'length' => ''
					,'collation' => 'A'
					,'null' => false
				)
			)
		),
		'metal' => array (
			'alias' => 'metal'
			,'primary' => false
			,'unique' => false
			,'type' => 'BTREE'
			,'columns' => array (
				'action' => array (
					'length' => ''
					,'collation' => 'A'
					,'null' => false
				)
			)	
		),
		'theme' => array (
			'alias' => 'theme'
			,'primary' => false
			,'unique' => false
			,'type' => 'BTREE'
			,'columns' => array (
				'action' => array (
					'length' => ''
					,'collation' => 'A'
					,'null' => false
				)
			)	
		)		
	)
		
);

<?php
$order = $modx->getObject('msOrder', 12135);
// $sum = round(number_format($order->get('delivery_cost'), 2, '.', '') * 100);
// print_r ($sum);

            $orderBundleItems = [];
            $totalSum = 0;
            
            $fp = fopen('persons.csv', 'w');
            
            foreach ($order->getMany('Products') as $product) {
                
                $price = round(number_format($product->get('price'), 2, '.', '') * 100);
                $sum = round(number_format($product->get('cost'), 2, '.', '') * 100);
                $totalSum = $totalSum + $sum;

                $productData = array(
                    'positionId' => $i,
                    'name' => $product->get('name'),
                    'quantity' => array(
                        'value' => $product->get('count'),
                        'measure' => $this->modx->lexicon('ms2_frontend_count_unit') ?: 'шт.'
                    ) ,
                    'itemPrice' => $price,
                    'itemAmount' => $sum,
                    'itemCode' => $product->get('product_id'),
                    'tax' => array(
                        'taxType' => $taxType,
                        'taxSum' => $taxSum
                    ),
                    'itemAttributes' => array(
                        'attributes' => array(
                            array(
                                'name' => 'paymentMethod',
                                'value' => $this->modx->getOption('ms2_payment_sbrbnk_ofd.payment_method', null, 1, true)
                            ), array(
                                'name' => 'paymentObject',
                                'value' => $this->modx->getOption('ms2_payment_sbrbnk_ofd.payment_object', null, 1, true)
                            )
                        )
                    ),
                );
                fputcsv($fp, $productData);
                $orderBundleItems[] = $productData;
                $i++;
            }
            fclose($fp);
            $diff = $order->get('cost') - ($totalSum / 100);
            // echo '$orderBundleItems: ';
            // echo '<pre>';
            // print_r ($orderBundleItems);   
            echo '<pre>';
            echo 'totalSum: ';
            print_r ($totalSum);
            echo '<pre>';
            echo 'Order cost: ';
            print_r ($order->get('cost'));
            echo '<pre>';
            echo 'Order Delivery: ';
            print_r ($order->get('delivery_cost'));
            echo '<pre>';
            echo '$diff: ';
            print_r ($diff);
            
            if (($delivery = $order->getOne('Delivery')) && $order->get('delivery_cost') > 0) {
                $sum = round(number_format($order->get('delivery_cost'), 2, '.', '') * 100);
                $totalSum = $totalSum + $sum;
                $orderBundleItems[] = array(
                    'positionId' => $i,
                    'name' => $delivery->get('name'),
                    'quantity' => array(
                        'value' => 1,
                        'measure' => $this->modx->lexicon('ms2_frontend_count_unit') ?: 'шт.'
                    ) ,
                    'itemPrice' => $sum,
                    'itemAmount' => $sum,
                    'itemCode' => $i . '_' . $delivery->get('id'),
                    'tax' => array(
                        'taxType' => $taxType,
                        'taxSum' => $taxSum
                    ),
                    'itemAttributes' => array(
                        'attributes' => array(
                            array(
                                'name' => 'paymentMethod',
                                'value' => $this->modx->getOption('ms2_payment_sbrbnk_ofd.payment_method', null, 1, true)
                            ),
                             array(
                                'name' => 'paymentObject',
                                'value' => $paymentDeliveryObject
                            )
                        )
                    ),
                );
                $i++;
            }
            
            
            if ($diff < 0) {
                $remain = round(number_format($order->get('cost') , 2, '.', '') * 100);
                $ratio = $order->get('cost') / ($totalSum / 100);
                
                echo '<pre>';
                echo 'ratio: ';
                print_r ($ratio);
                
                
                $positions = count($orderBundleItems);
                for ($idx = 0; $idx < $positions; $idx++) {
                    $newItemPrice = round($orderBundleItems[$idx]['itemPrice'] * $ratio);
                    
                    if ($positions > $idx + 1) {
                        $newItemAmount = round($orderBundleItems[$idx]['itemAmount'] * $ratio);
                        $remain = $remain - $newItemAmount;
                    } else {
                        $newItemAmount = $remain;
                    }

                    if ($newItemAmount != $newItemPrice) {
                        $newItemPrice = $newItemAmount;
                    }

                    $orderBundleItems[$idx]['itemPrice'] = $newItemPrice;
                    $orderBundleItems[$idx]['itemAmount'] = $newItemAmount;
                }
            }
            echo '<pre>';
            echo '$orderBundleItems Final: ';
            echo '<pre>';
            print_r ($orderBundleItems);